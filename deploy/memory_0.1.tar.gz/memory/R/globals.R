globalVariables(unique(c(
  # mem_history: 
  "time", "y", "y2"
)))